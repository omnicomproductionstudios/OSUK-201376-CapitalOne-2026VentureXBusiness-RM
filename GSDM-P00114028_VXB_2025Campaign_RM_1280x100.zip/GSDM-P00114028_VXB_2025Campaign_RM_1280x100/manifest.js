FT.manifest({
	"filename":"GSDM-P00114028_VXB_2025Campaign_RM_1280x100.html",
	"width":1280,
	"height":100,
	"clickTagCount":1,
  "videos":[{"name":"video1", "ref":"231590/TURW5182100H_P00115797_VXB_GOING_THE_DISTANCE_OLV_15_HD_20251202_H264"}],
	"expand":{
		"fullscreen":false,
		"width":1280,
		"height":418,
		"indentAcross":0,
		"indentDown":0
  }
});
