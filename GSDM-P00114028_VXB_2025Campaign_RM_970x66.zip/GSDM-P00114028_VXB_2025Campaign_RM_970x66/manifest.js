FT.manifest({
	"filename":"GSDM-P00114028_VXB_2025Campaign_RM_970x66.html",
	"width":970,
	"height":66,
	"clickTagCount":1,
  "videos":[{"name":"video1", "ref":"231590/TURW5182100H_P00115797_VXB_GOING_THE_DISTANCE_OLV_15_HD_20251202_H264"}],
	"expand":{
		"fullscreen":false,
		"width":970,
		"height":250,
		"indentAcross":0,
		"indentDown":0
  }
});
